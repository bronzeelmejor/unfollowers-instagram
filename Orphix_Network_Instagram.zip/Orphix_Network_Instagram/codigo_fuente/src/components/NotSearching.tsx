import React from 'react';
import { Language, t } from '../utils/i18n';
import { UserNode } from '../model/user';
interface NotSearchingProps { onScan?: () => void; lang: Language; cachedScan?: { readonly results: readonly UserNode[]; readonly timestamp: number } | null; onLoadCached?: () => void; }
export const NotSearching = ({onScan, lang, cachedScan, onLoadCached}: NotSearchingProps) => {
 const es = lang === 'es';
 return <section className="orphix-home">
  <div className="orphix-context"><span>SOCIAL INTELLIGENCE</span><span className="orphix-online">{es ? 'Sesión del navegador' : 'Browser session'}</span></div>
  <div className="orphix-hero">
   <div className="orphix-intro"><span className="orphix-kicker">ORPHIX NETWORK / INSTAGRAM</span><h1>{es ? 'Tu comunidad.' : 'Your community.'}<br/><em>{es ? 'Sin ruido.' : 'Without the noise.'}</em></h1><p>{es ? 'Descubre quién no te sigue de vuelta. Organiza tus conexiones y decide a quién quieres mantener cerca.' : 'Find who does not follow you back. Organize your connections and choose who to keep close.'}</p>
   <div className="orphix-actions"><button type="button" className="run-scan" onClick={onScan}>{es ? 'Analizar mi cuenta' : 'Analyze my account'} <span aria-hidden="true">↗</span></button>{cachedScan && cachedScan.results.length > 0 && onLoadCached ? <button type="button" className="load-cached-scan" onClick={onLoadCached}>{es ? 'Abrir último análisis' : 'Open last analysis'} <span aria-hidden="true">↺</span></button> : null}</div>
   <div className="orphix-caption"><span aria-hidden="true">◇</span> {es ? 'Tú revisas. Tú seleccionas. Tú decides.' : 'You review. You select. You decide.'}</div></div>
   <aside className="orphix-console"><div className="orphix-console-top"><span><b aria-hidden="true">◈</b> {es ? 'Centro de análisis' : 'Analysis center'}</span><span className="orphix-chip">{es ? 'EN ESPERA' : 'STANDBY'}</span></div>
    <div className="orphix-console-main"><span>{es ? 'CUENTAS EN EL ÚLTIMO ANÁLISIS' : 'ACCOUNTS IN LAST ANALYSIS'}</span><strong>{cachedScan ? cachedScan.results.length : '—'}</strong><p>{cachedScan ? (es ? 'Resultados guardados disponibles' : 'Saved results available') : (es ? 'Todo empieza con un primer escaneo' : 'Start with your first scan')}</p><div className="orphix-bars" aria-hidden="true">{[24,40,30,65,48,75,58,90,70,100,83,66,92,76,100,86].map((height,i)=><i key={i} style={{height: `${height}%`}}/>)}</div><small>{es ? 'Visualización decorativa · sin datos en directo' : 'Decorative visualization · no live data'}</small></div>
    <div className="orphix-console-bottom"><span>◌ {es ? 'Ejecución local' : 'Local execution'}</span><span>JSON / CSV</span></div>
   </aside>
  </div>
  <div className="orphix-features">{(es ? [['01','Analiza tus conexiones','Consulta quién no te sigue de vuelta al completar el análisis.'],['02','Protege tus favoritos','Guarda las cuentas que quieres conservar en tu lista blanca.'],['03','Revisa y exporta','Busca perfiles, selecciona resultados y descarga tu lista.']] : [['01','Analyze connections','See who does not follow you back after the scan finishes.'],['02','Protect your favorites','Keep chosen accounts in your whitelist.'],['03','Review and export','Search profiles, select results and download your list.']]).map(([n,title,body])=><article key={n}><span>{n}</span><h2>{title}</h2><p>{body}</p></article>)}</div>
  <footer className="orphix-footer"><span>ORPHIX NETWORK <b>Social Audit</b></span><span>{t(lang,'runsInBrowserOnly')}</span></footer>
 </section>;
};
