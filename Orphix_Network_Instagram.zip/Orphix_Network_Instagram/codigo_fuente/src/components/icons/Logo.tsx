import React, { FC } from "react";
export const Logo: FC = () => <svg width="42" height="42" viewBox="0 0 48 48" fill="none" aria-hidden="true"><path d="M24 3 43 14v20L24 45 5 34V14L24 3Z" fill="#17172f" stroke="#9280ff" strokeWidth="2"/><path d="m16 18 8-5 8 5v12l-8 5-8-5V18Z" stroke="#b7a8ff" strokeWidth="3"/><path d="m24 13 8 5v12" stroke="#55e0e1" strokeWidth="3"/></svg>;
